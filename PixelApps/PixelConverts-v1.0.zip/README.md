# File Converter

Uma aplicação simples para converter arquivos de um formato para outro.

## Como usar

1. Faça download dos seguintes arquivos:
   - `file-converter-1.0-SNAPSHOT-jar-with-dependencies.jar`
   - `run-converter.bat`
2. Coloque os arquivos na mesma pasta
3. Dê dois cliques no arquivo `run-converter.bat`
4. Se o Java não estiver instalado, o script irá baixar e instalar automaticamente

## Notas
- A primeira execução pode demorar alguns minutos se for necessário instalar o Java
- É necessário ter permissões de administrador para a instalação automática do Java
- Conexão com internet é necessária apenas se o Java precisar ser instalado